function Txt2Json(txtPath){
    let fr=new FileReader();
    fr.readAsText(txtPath);
    fr.onload=function(){
        let lines = fr.result.split('\n');
        let jsonAry = new Array();
        let errCode,typ;

        for (let i = 0; i < lines.length; i++) {
            if(lines[i].charAt(6)=="|"){
                let tmpJson = lines[i].split("|");
                if(tmpJson[0].includes("S")||tmpJson[0].includes("U")){
                    errCode=tmpJson[0]
                    typ=""
                    // jsonAry.push(JSON.stringify({ErrorCode:errCode,Type:"-",Condition:tmpJson[1]}))
                    jsonAry.push({ErrorCode:errCode,Name:tmpJson[1]})
                }else{
                    if(tmpJson[0].includes("-")){
                        typ=tmpJson[0]
                        // jsonAry.push(JSON.stringify({ErrorCode:errCode,Type:typ,Condition:tmpJson[1]}))
                        jsonAry.push({ErrorCode:errCode,Type:typ,Condition:tmpJson[1]})
                    }else{
                        if(typ.includes("-")){
                            // jsonAry.push(JSON.stringify({ErrorCode:errCode,Type:typ,Condition:tmpJson[1]}))
                            jsonAry.push({ErrorCode:errCode,Type:typ,Condition:tmpJson[1]})
                        }else{
                            // jsonAry.push(JSON.stringify({ErrorCode:errCode,Type:"-",Condition:tmpJson[1]}))
                            jsonAry.push({ErrorCode:errCode,Name:tmpJson[1]})
                        }
                    }
                }
            }
        }

        localStorage.setItem("tmpDB", JSON.stringify(jsonAry));
        console.log(jsonAry);
        
        // saveJson(jsonAry);
    }
}

function test(){
    localStorage.setItem("tmpDB", "asdfg");
}
// function saveJson(data){
//     var blob = new Blob(data,{type:"application/json"})//new Blob(data);
//     var url = URL.createObjectURL(blob);

//     var a = document.createElement('a');
//     a.download = "Tmp.json";
//     a.href = url;
//     a.click();
//     console.log("Finished");
// }

// function ReadJSON(){
//     fetch('C:\\Users\\25-00226\\Downloads\\Tmp(2).json')
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//         })
//         .catch(error => {
//             console.error("Error ", error);
//         })    
// }

// function testVB(){
//     var fs = new ActiveXObject("Scripting.FileSystemObject");
//     var file = fs.GetFile("C:\\Users\\25-00226\\Downloads\\jTmp.json");
//     console.log(file.Size);
// }

// function writeToDisk(tmpAry) {
//     var fso = new ActiveXObject("Scripting.FileSystemObject");
//     var a = fso.CreateTextFile("C:\\Users\\25-00226\\Desktop\\TestLog.txt", true);
//     a.WriteLine(tmpAry);
//     a.Close();
// }

// function test(tmp){
//     tmp[1].ErrorCode = 12723
//     // JSON.parse(jsonAry);
//     console.log("After");
//     console.log(tmp);
// }

// function loadJSON(callback) {   

//     var xobj = new XMLHttpRequest();
//         xobj.overrideMimeType("application/json");
//     xobj.open('GET', 'my_data.json', true); // Replace 'my_data' with the path to your file
//     xobj.onreadystatechange = function () {
//           if (xobj.readyState == 4 && xobj.status == "200") {
//             // Required use of an anonymous callback as .open will NOT return a value but simply returns undefined in asynchronous mode
//             callback(xobj.responseText);
//           }
//     };
//     xobj.send(null);  
//  }